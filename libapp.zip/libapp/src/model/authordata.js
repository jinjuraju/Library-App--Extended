//Accessing Mongoose package
const mongoose=require('mongoose');
//database collection
mongoose.connect('mongodb+srv://userone:userone@ictakfiles.s1ufx.mongodb.net/LIBRARYAPP?retryWrites=true&w=majority');
//schema definition
const schema=mongoose.Schema;

const authorSchema=new schema({
    title: String,
    author : String,
    genre : String,
    image : String
});
//model creation
var authorData = mongoose.model('authordata',authorSchema);

module.exports=authorData;