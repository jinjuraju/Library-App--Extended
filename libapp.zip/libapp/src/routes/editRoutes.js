const express = require('express');
const editRouter=express.Router();
const bookData=require('../model/bookdata')
function router(nav){
    editRouter.get('/',function(req,res){
        res.render("addbook",
        {
            nav:nav,
            title:'Library',
        });
    });
    editRouter.post('/delete',function(req,res){
        bookData.deleteMany({_id:{$in:req.body.delete}},function(err,result){
            if (err) throw err
            else{
                res.render('success', {
                    message: `Updating Book List`,
                    rediectPage: '/books'
                });
            }
        });
    });
    return addbooksRouter;
}

module.exports=router;