const express = require('express');
const addbooksRouter=express.Router();
const bookData=require('../model/bookdata')
function router(nav){
    addbooksRouter.get('/',function(req,res){
        res.render("addbook",
        {
            nav:nav,
            title:'Library',
        });
    });
    addbooksRouter.post('/add',function(req,res){
        var item = {
            title : req.body.title,
            author : req.body.author,
            genre : req.body.genre,
            image : req.body.image
        }
        var book = bookData(item);
        //console.log(req);
        book.save();//saving to database
        res.redirect('/books');
        //res.send('hey i am added');
    });
    return addbooksRouter;
}

module.exports=router;