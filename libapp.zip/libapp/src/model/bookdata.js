//Accessing Mongoose package
const mongoose=require('mongoose');
//database collection
mongoose.connect('mongodb+srv://userone:userone@ictakfiles.s1ufx.mongodb.net/LIBRARYAPP?retryWrites=true&w=majority');
//schema definition
const schema=mongoose.Schema;

const bookSchema=new schema({
    title: String,
    author : String,
    genre : String,
    image : String
});
//model creation
var bookData = mongoose.model('bookdata',bookSchema);

module.exports=bookData;